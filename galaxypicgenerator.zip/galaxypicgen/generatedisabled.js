#!/usr/bin/env node
"use strict";
/**
 * generate.js — Spaceflight Simulator galaxy view renderer
 * ---------------------------------------------------------------------------
 * Renders a standalone image of the game's galaxy view (the zoomed-out tier
 * you see at metersPerPixel >= ~1e13, i.e. isGalaxyViewActive() in the game
 * source), centered on Sagittarius A*, using the game's own galaxy
 * generation code (see game-galaxy-core.js for the extraction notes).
 *
 * USAGE
 *   node generate.js                       # uses CONFIG below
 *   node generate.js --stars 50000 --zoom 1e14 --width 2048 --height 2048
 *   node generate.js --out mygalaxy.png --dotSize 3 --seed 42
 *
 * All flags are optional and override the CONFIG object below. Edit CONFIG
 * directly if you don't want to bother with flags.
 * ---------------------------------------------------------------------------
 */
const path = require("path");
const {
  SGR_A_POS,
  galaxySeedPosition,
  proceduralStarColor,
  quantizeColorBucket,
  GALAXY_DOT_OVERLAP_RATIO,
  buildFixedStars,
} = require("./game-galaxy-core");
const { Framebuffer, hexToRgb } = require("./lib/framebuffer");

// ===========================================================================
// CONFIG — edit these defaults, or override any of them with a CLI flag of
// the same name (e.g. `node generate.js --stars 200000`).
// ===========================================================================
const CONFIG = {
  stars: 1000000, // number of procedurally generated star systems to place
  zoomMetersPerPixel: 4.44e12, // world meters represented by one pixel
  width: 16384, // output image width, px
  height: 16384, // output image height, px
  starPixelSize: 1, // diameter, in px, of each rendered star dot
  output: "galaxy.png", // output file path
  seed: null, // optional: integer to make the run reproducible (tool-only
  // feature — the game itself picks random seeds via Math.random()
  // each time you use its "spawn random systems" tool)
};

// ---------------------------------------------------------------------------
// Minimal CLI flag parsing: --key value (also accepts --key=value)
// ---------------------------------------------------------------------------
function parseArgs(argv, config) {
  const aliases = { out: "output", zoomMPP: "zoomMetersPerPixel", zoom: "zoomMetersPerPixel", dotSize: "starPixelSize" };
  for (let i = 0; i < argv.length; i++) {
    let arg = argv[i];
    if (!arg.startsWith("--")) continue;
    arg = arg.slice(2);
    let key, value;
    if (arg.includes("=")) {
      [key, value] = arg.split(/=(.+)/);
    } else {
      key = arg;
      value = argv[i + 1];
      i++;
    }
    if (key === "help" || key === "h") {
      printHelp();
      process.exit(0);
    }
    key = aliases[key] || key;
    if (!(key in config)) {
      console.error(`Unknown option --${key}`);
      printHelp();
      process.exit(1);
    }
    if (key === "output") config[key] = value;
    else config[key] = Number(value);
  }
  return config;
}

function printHelp() {
  console.log(`Spaceflight Simulator galaxy renderer

Options (all optional, override CONFIG in generate.js):
  --stars N              number of procedural star systems (default ${CONFIG.stars})
  --zoom N                 meters per pixel, alias --zoomMPP (default ${CONFIG.zoomMetersPerPixel})
  --width N                 output width in px (default ${CONFIG.width})
  --height N                output height in px (default ${CONFIG.height})
  --dotSize N              star dot diameter in px, alias --starPixelSize (default ${CONFIG.starPixelSize})
  --out PATH                output PNG path, alias --output (default ${CONFIG.output})
  --seed N                  optional integer for reproducible runs (tool-only; omit for
                             game-like fresh-random selection each run)
  --help                    show this message
`);
}

// ---------------------------------------------------------------------------
// Small seeded PRNG for --seed (mulberry32-style, only used to pick WHICH
// star seeds get generated when reproducibility is requested; the galaxy
// generation math itself is always the game's own code regardless).
// ---------------------------------------------------------------------------
function makeSeedPicker(seedArg) {
  if (seedArg == null) {
    return () => 1 + Math.floor(Math.random() * 1e6); // matches game's randomSeedValue()
  }
  let t = seedArg >>> 0;
  const rng = function () {
    t = (t + 1831565813) | 0;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r = (r + Math.imul(r ^ (r >>> 7), 61 | r)) ^ r;
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
  return () => 1 + Math.floor(rng() * 1e6);
}

// ---------------------------------------------------------------------------
// world -> screen transform, matching worldToScreen() in the game source
// (source lines 7978-7995), with camera.angle = 0 (galaxy view is never
// rotated in the game either) and the camera centered on Sagittarius A*.
// ---------------------------------------------------------------------------
function makeWorldToScreen(config) {
  const camX = SGR_A_POS.x,
    camY = SGR_A_POS.y;
  const mpp = config.zoomMetersPerPixel;
  const cw = config.width,
    ch = config.height;
  return function worldToScreen(wx, wy) {
    const dx = (wx - camX) / mpp;
    const dy = -(wy - camY) / mpp;
    return { x: cw / 2 + dx, y: ch / 2 + dy };
  };
}

// ---------------------------------------------------------------------------
// Background: solid fill + the game's twinkling starfield decoration.
// Source lines 8195-8218 (STARS array) and 11397-11411 (render()). The
// game's STARS array is built with unseeded Math.random() once per page
// load, so it's non-deterministic in the game too — we reproduce the exact
// distribution, not a specific frozen instance.
// ---------------------------------------------------------------------------
function drawBackgroundStars(fb) {
  fb.fillRect(20, 20, 20, 255);
  const size = Math.ceil(Math.hypot(fb.width, fb.height));
  const offsetX = fb.width / 2 - size / 2;
  const offsetY = fb.height / 2 - size / 2;
  for (let i = 0; i < 500; i++) {
    const rx = Math.random(),
      ry = Math.random();
    const r = Math.random() * 1.3 + 0.3;
    const a = Math.random() * 0.5 + 0.35;
    const px = offsetX + rx * size;
    const py = offsetY + ry * size;
    drawSoftCircleWithAlpha(fb, px, py, r, 255, 255, 255, a);
  }
}

function drawSoftCircleWithAlpha(fb, cx, cy, radius, r, g, b, alpha) {
  const minX = Math.max(0, Math.floor(cx - radius - 1));
  const maxX = Math.min(fb.width - 1, Math.ceil(cx + radius + 1));
  const minY = Math.max(0, Math.floor(cy - radius - 1));
  const maxY = Math.min(fb.height - 1, Math.ceil(cy + radius + 1));
  for (let py = minY; py <= maxY; py++) {
    for (let px = minX; px <= maxX; px++) {
      const dx = px + 0.5 - cx;
      const dy = py + 0.5 - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const coverage = Math.max(0, Math.min(1, radius - dist + 0.5)) * alpha;
      if (coverage > 0) fb.blendPixel(px, py, r, g, b, coverage);
    }
  }
}

// ===========================================================================
// Main
// ===========================================================================
function main() {
  const config = parseArgs(process.argv.slice(2), Object.assign({}, CONFIG));
  if (!Number.isFinite(config.stars) || config.stars < 0) {
    console.error("Invalid --stars value");
    process.exit(1);
  }

  console.log("Spaceflight Simulator galaxy renderer");
  console.log(
    `  stars=${config.stars} zoom=${config.zoomMetersPerPixel} m/px  ${config.width}x${config.height}px  dot=${config.starPixelSize}px`
  );

  const fb = new Framebuffer(config.width, config.height);
  drawBackgroundStars(fb);

  const worldToScreen = makeWorldToScreen(config);
  const r = config.starPixelSize / 2;
  const overlapDist = r * 2 * GALAXY_DOT_OVERLAP_RATIO;
  const overlapDistSq = overlapDist * overlapDist;
  const cellSize = Math.max(1, overlapDist);
  const gridHeads = new Map(); // matches the game's _t3GridHeads dedup grid
  const acceptedX = [];
  const acceptedY = [];
  const acceptedNext = [];
  const W = config.width,
    H = config.height;

  function cellKey(cx, cy) {
    return cx * 2000000 + cy; // arbitrary but collision-free for our grid range
  }

  function tryPlaceDot(sx, sy) {
    if (sx < -r - 2 || sx > W + r + 2 || sy < -r - 2 || sy > H + r + 2) return false;
    const cx = Math.floor(sx / cellSize),
      cy = Math.floor(sy / cellSize);
    for (let gx = cx - 1; gx <= cx + 1; gx++) {
      for (let gy = cy - 1; gy <= cy + 1; gy++) {
        let idx = gridHeads.get(cellKey(gx, gy));
        while (idx !== undefined) {
          const dx = acceptedX[idx] - sx,
            dy = acceptedY[idx] - sy;
          if (dx * dx + dy * dy < overlapDistSq) return false;
          idx = acceptedNext[idx];
        }
      }
    }
    const idx = acceptedX.length;
    acceptedX.push(sx);
    acceptedY.push(sy);
    const key = cellKey(cx, cy);
    acceptedNext.push(gridHeads.get(key));
    gridHeads.set(key, idx);
    return true;
  }

  // Procedural stars: same seed-selection mechanism as the game's
  // addRandomProceduralSystems(count) (source line 12457), same per-seed
  // position/color generation, same overlap-culling grid as
  // drawGalaxyDotsTier3 (source lines 11185-11277) at steady state (a dot
  // is either fully drawn or fully culled — no need to animate a fade for
  // a single static image).
  const pickSeed = makeSeedPicker(config.seed);
  const batches = new Map(); // bucketColor -> [[x,y], ...]
  let placed = 0;
  for (let i = 0; i < config.stars; i++) {
    const seed = pickSeed();
    const pos = galaxySeedPosition(seed);
    const screen = worldToScreen(pos.x, pos.y);
    if (!tryPlaceDot(screen.x, screen.y)) continue;
    const { color } = proceduralStarColor(seed);
    const bucket = quantizeColorBucket(color);
    let arr = batches.get(bucket);
    if (!arr) {
      arr = [];
      batches.set(bucket, arr);
    }
    arr.push(screen.x, screen.y);
    placed++;
  }

  for (const [bucket, coords] of batches) {
    const { r: cr, g: cg, b: cb } = hexToRgb(bucket);
    for (let i = 0; i < coords.length; i += 2) {
      fb.drawCircle(coords[i], coords[i + 1], r, cr, cg, cb);
    }
  }

  // Hardcoded stars are always drawn (only 7 of them; not subject to the
  // overlap-culling grid, and drawn on top so they stay visible landmarks).
  const fixedStars = buildFixedStars();
  for (const star of fixedStars) {
    const screen = worldToScreen(star.pos.x, star.pos.y);
    const { r: cr, g: cg, b: cb } = hexToRgb(star.color);
    fb.drawCircle(screen.x, screen.y, r, cr, cg, cb);
  }

  const outPath = path.resolve(process.cwd(), config.output);
  fb.writeToFile(outPath);
  console.log(`Placed ${placed}/${config.stars} procedural stars (rest overlapped and were culled, matching the game's dot-overlap behavior).`);
  console.log(`Wrote ${outPath}`);
}

main();