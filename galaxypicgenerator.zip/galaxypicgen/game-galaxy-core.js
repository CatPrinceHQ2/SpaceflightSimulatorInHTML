"use strict";
/**
 * game-galaxy-core.js
 * ---------------------------------------------------------------------------
 * Extraction notes
 * ---------------------------------------------------------------------------
 * Extracted from SFS1_6_0.html (Spaceflight Simulator in HTML, R1.6.0,
 * https://github.com/CatPrinceHQ2/SpaceflightSimulatorInHTML). All constants
 * and functions below are copied verbatim (formatting aside) from the
 * game's single-file source, so that `generate.js` reproduces the exact
 * same galaxy the game itself renders in its zoomed-out galaxy-view tier.
 *
 * Source line references (SFS1_6_0.html, R1.6.0, 12570 lines):
 *   - AU, SUN_POS, GM_SUN, STAR_GLOW_ATMO_FRAC ............. 824-858
 *   - Alpha Centauri / Tau Ceti / Gliese 876 / Sgr A* anchor
 *     positions and fixed-star registrations ................ 1696-1917
 *   - galaxyHash2 / galaxySmooth / galaxyValueNoise / galaxyFbm
 *     / galaxyDiskTaper / galaxyDiskRadial / galaxyHaloRadial
 *     / galaxyDensityAt (density field + 2-arm spiral) ....... 1930-2017
 *   - galaxyRadialBound / GALAXY_RADIAL_CDF / galaxySampleRadius
 *     (importance-sampling for radius) ....................... 2018-2065
 *   - mulberry32 / rngRange / rngInt (seeded PRNG) .......... 2333-2349
 *   - hslToRgb / enforceBrightnessFloor / toHexColor ........ 2351-2418
 *   - proceduralColor (star/planet HSL color roll) .......... 2420-2438
 *   - PROC_STAR_PREFIXES / proceduralStarName ................ 2457-2478
 *   - PROC_MUSIC_THEMES / PROC_MUSIC_BASE_HZ /
 *     pickProcMusicSemitone .................................. 2479-2494
 *   - galaxySeedPosition (rejection-sample a star's position
 *     from the density field) ................................ 2539-2567
 *   - buildProceduralStarStub (the rng draw order that
 *     proceduralStarColor() below replicates) ................ 3108-3226
 *   - quantizeColorBucket / GALAXY_DOT_RADIUS_PX /
 *     GALAXY_DOT_COLOR_BUCKET ................................ 10998-10999, 11129-11137
 *   - GALAXY_DOT_OVERLAP_RATIO + drawGalaxyDotsTier3 dedup
 *     grid (reimplemented in generate.js, not here) .......... 11157, 11185-11277
 *
 * IMPORTANT — proceduralStarColor(seed) and the shared RNG stream:
 * In the game, a procedural star's color is NOT generated in isolation.
 * buildProceduralStarStub(seed) seeds one mulberry32 stream from the seed
 * and draws from it, IN ORDER, for: GM multiplier, radius multiplier, star
 * name (a variable number of draws depending on how many name syllables
 * get rolled), music theme, music semitone offset, and only THEN the star's
 * HSL color. Because mulberry32 is a stateful stream, the color depends on
 * every draw that happened before it — skipping or reordering any of those
 * draws (e.g. trying to shortcut straight to "the color roll") silently
 * desyncs the stream and produces the WRONG color for that seed. So
 * proceduralStarColor() below reproduces the entire draw sequence exactly
 * as buildProceduralStarStub() does (name prefixes included), and simply
 * discards everything but the resulting color. It does not consult or
 * reproduce the game's rarity system (getSystemRarity/rarityTierRng/
 * rarityVariantRng) because those are separately-seeded streams
 * (rarityTierRng/rarityVariantRng hash the seed differently and do not
 * consume from the same mulberry32 stream as the name/color draws) and
 * never influence proceduralColor()'s inputs for the star itself — the
 * `purpleBias` rarity tiers only affect *planet* colors, computed later
 * in the game via a separate `generateStarPlanetDefs` codepath that this
 * galaxy-only extraction doesn't need.
 *
 * IMPORTANT — the 7 fixed stars and binary orbital motion:
 * Alpha Centauri A and B orbit their mutual barycenter (23.7 AU apart,
 * ecc 0.518), and Proxima Centauri orbits the same barycenter at 50 AU.
 * The game resolves their exact positions at a given simTime via Keplerian
 * orbit-solving (planetPositionAt / binaryPairPosition / solveKepler).
 * At galaxy-view zoom (this tool's default is 2.22e14 meters/pixel), those
 * orbital separations (tens of AU, i.e. ~1e12-1e13 meters) are on the
 * order of a hundredth of a pixel — completely invisible, exactly as they
 * are in the game's own galaxy view. buildFixedStars() below places all
 * three at the fixed ALPHA_CEN_ANCHOR_POS barycenter rather than
 * reproducing the full Keplerian solver, which would add real complexity
 * for a sub-pixel, visually-undetectable correction at this rendering
 * tier. The other four fixed stars (Sun, Tau Ceti, Gliese 876,
 * Sagittarius A*) have no parent and use their literal `pos` from the
 * source, unchanged.
 * ---------------------------------------------------------------------------
 */

// ===========================================================================
// Base constants (source lines 824-858, 1696-1930)
// ===========================================================================
const AU = 1496e6;
const SUN_POS = { x: 0, y: 0 };
const GM_SUN = 0x46baa56d4b6d08;

const ALPHA_CEN_SYSTEM_DIST_AU = 1110;
const ALPHA_CEN_SYSTEM_Y_AU = 254;
const ALPHA_CEN_ANCHOR_POS = {
  x: ALPHA_CEN_SYSTEM_DIST_AU * AU,
  y: ALPHA_CEN_SYSTEM_Y_AU * AU,
};

const ALPHA_CEN_DIR_ANGLE = Math.atan2(ALPHA_CEN_SYSTEM_Y_AU, ALPHA_CEN_SYSTEM_DIST_AU);
const TAU_CETI_DIR_ANGLE = ALPHA_CEN_DIR_ANGLE + (110 * Math.PI) / 180;
const ALPHA_CEN_REAL_LY = 4.37,
  TAU_CETI_REAL_LY = 11.9;
const ALPHA_CEN_GAME_DIST_AU = Math.hypot(ALPHA_CEN_SYSTEM_DIST_AU, ALPHA_CEN_SYSTEM_Y_AU);
const TAU_CETI_DIST_AU = ALPHA_CEN_GAME_DIST_AU * (TAU_CETI_REAL_LY / ALPHA_CEN_REAL_LY);
const TAU_CETI_POS = {
  x: TAU_CETI_DIST_AU * AU * Math.cos(TAU_CETI_DIR_ANGLE),
  y: TAU_CETI_DIST_AU * AU * Math.sin(TAU_CETI_DIR_ANGLE),
};

const GLIESE876_REAL_LY = 15.2;
const GLIESE876_DIR_ANGLE = ALPHA_CEN_DIR_ANGLE + (80.7 * Math.PI) / 180;
const GLIESE876_DIST_AU = ALPHA_CEN_GAME_DIST_AU * (GLIESE876_REAL_LY / ALPHA_CEN_REAL_LY);
const GLIESE876_POS = {
  x: GLIESE876_DIST_AU * AU * Math.cos(GLIESE876_DIR_ANGLE),
  y: GLIESE876_DIST_AU * AU * Math.sin(GLIESE876_DIR_ANGLE),
};

const SGR_A_DIST_AU = ALPHA_CEN_GAME_DIST_AU * 6070;
const SGR_A_DIR_ANGLE = ALPHA_CEN_DIR_ANGLE + (200 * Math.PI) / 180;
const SGR_A_POS = {
  x: SGR_A_DIST_AU * AU * Math.cos(SGR_A_DIR_ANGLE),
  y: SGR_A_DIST_AU * AU * Math.sin(SGR_A_DIR_ANGLE),
};
const SAGITTARIUS_A_SOI = SGR_A_DIST_AU * AU * 0.0175;

const PROC_REGION_CENTER = SGR_A_POS;
const PROC_REGION_MIN_RADIUS = SAGITTARIUS_A_SOI * 3;
const GALAXY_CORE_RADIUS = PROC_REGION_MIN_RADIUS;
const GALAXY_SUN_R = SGR_A_DIST_AU * AU;
const GALAXY_SCALE_R = GALAXY_SUN_R;
const GALAXY_DISK_DECAY_R = GALAXY_SUN_R * 1.3;
const GALAXY_DISK_TAPER_START = 1.6;
const GALAXY_DISK_TAPER_END = 4;
const GALAXY_HALO_SCALE_R = GALAXY_SUN_R * 2.6;
const GALAXY_HALO_AMPLITUDE = 0.005;
const GALAXY_MAX_SAMPLE_R = GALAXY_SUN_R * 38.5;
const GALAXY_NUM_ARMS = 2;
const GALAXY_PITCH = 3;
const GALAXY_WIND_FLOOR_R = GALAXY_SCALE_R * 0.15;
const GALAXY_ARM_WIDTH_BASE = 0.38;
const GALAXY_INTERARM = 0.2;
const GALAXY_NOISE_FREQ = 300;

const _galSunRelX = SUN_POS.x - PROC_REGION_CENTER.x,
  _galSunRelY = SUN_POS.y - PROC_REGION_CENTER.y;
const _galSunR = Math.hypot(_galSunRelX, _galSunRelY);
const _galSunTheta = Math.atan2(_galSunRelY, _galSunRelX);
const GALAXY_ARM_PHASE0 =
  _galSunTheta - GALAXY_PITCH * Math.log(Math.max(_galSunR, GALAXY_WIND_FLOOR_R) / GALAXY_SCALE_R);

// ===========================================================================
// Density field + spiral arms (source lines 1942-2017)
// ===========================================================================
function galaxyHash2(ix, iy) {
  let h = ((ix * 374761393 + iy * 668265263) | 0);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h = h ^ (h >>> 16);
  return ((h >>> 0) % 1e5) / 1e5;
}

function galaxySmooth(t) {
  return t * t * (3 - 2 * t);
}

function galaxyValueNoise(x, y) {
  const x0 = Math.floor(x),
    y0 = Math.floor(y),
    x1 = x0 + 1,
    y1 = y0 + 1;
  const sx = galaxySmooth(x - x0),
    sy = galaxySmooth(y - y0);
  const n00 = galaxyHash2(x0, y0),
    n10 = galaxyHash2(x1, y0),
    n01 = galaxyHash2(x0, y1),
    n11 = galaxyHash2(x1, y1);
  const ix0 = n00 + (n10 - n00) * sx,
    ix1 = n01 + (n11 - n01) * sx;
  return ix0 + (ix1 - ix0) * sy;
}

function galaxyFbm(x, y) {
  return (
    galaxyValueNoise(x, y) * 0.6 +
    galaxyValueNoise(x * 2.17 + 11.3, y * 2.17 - 7.1) * 0.3 +
    galaxyValueNoise(x * 4.31 - 3.7, y * 4.31 + 5.9) * 0.1
  );
}

function galaxyDiskTaper(r) {
  const u = r / GALAXY_SUN_R;
  if (u <= GALAXY_DISK_TAPER_START) return 1;
  if (u >= GALAXY_DISK_TAPER_END) return 0;
  return 1 - galaxySmooth((u - GALAXY_DISK_TAPER_START) / (GALAXY_DISK_TAPER_END - GALAXY_DISK_TAPER_START));
}

function galaxyDiskRadial(r) {
  const diskEnv = Math.exp(-r / GALAXY_DISK_DECAY_R);
  const bulge = 1 + 3.2 * Math.exp(-r / (GALAXY_CORE_RADIUS * 4));
  return diskEnv * bulge * galaxyDiskTaper(r);
}

function galaxyHaloRadial(r) {
  return GALAXY_HALO_AMPLITUDE * Math.exp(-r / GALAXY_HALO_SCALE_R);
}

function galaxyDensityAt(x, y) {
  const r = Math.hypot(x, y);
  if (r < 1) return 0;
  const theta = Math.atan2(y, x);
  const diskRadial = galaxyDiskRadial(r);
  const armWidth = GALAXY_ARM_WIDTH_BASE * (0.45 + 0.35 * Math.min(1, r / GALAXY_SCALE_R));
  let armFactor = 0;
  for (let k = 0; k < GALAXY_NUM_ARMS; k++) {
    const armAngle =
      GALAXY_ARM_PHASE0 +
      k * ((2 * Math.PI) / GALAXY_NUM_ARMS) +
      GALAXY_PITCH * Math.log(Math.max(r, GALAXY_WIND_FLOOR_R) / GALAXY_SCALE_R);
    let d = theta - armAngle;
    d = (((d + Math.PI) % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI) - Math.PI;
    armFactor += Math.exp(-(d * d) / (2 * armWidth * armWidth));
  }
  armFactor = Math.min(1, armFactor);
  const armDensity = GALAXY_INTERARM + (1 - GALAXY_INTERARM) * armFactor;
  const nx = (x / GALAXY_SCALE_R) * GALAXY_NOISE_FREQ,
    ny = (y / GALAXY_SCALE_R) * GALAXY_NOISE_FREQ;
  const diskNoise = 0.35 + 1.3 * galaxyFbm(nx, ny);
  const diskPart = diskRadial * armDensity * diskNoise;
  const haloRadial = galaxyHaloRadial(r);
  const hx = (x / GALAXY_SCALE_R) * (GALAXY_NOISE_FREQ * 0.35) + 50.7,
    hy = (y / GALAXY_SCALE_R) * (GALAXY_NOISE_FREQ * 0.35) - 31.4;
  const haloNoise = 0.5 + 0.5 * galaxyFbm(hx, hy);
  const haloPart = haloRadial * haloNoise;
  return diskPart + haloPart;
}

const GALAXY_DISK_ANGULAR_MAX = 1.7;
const GALAXY_HALO_ANGULAR_MAX = 1;

function galaxyRadialBound(r) {
  return galaxyDiskRadial(r) * GALAXY_DISK_ANGULAR_MAX + galaxyHaloRadial(r) * GALAXY_HALO_ANGULAR_MAX;
}

// Precomputed radial CDF for importance-sampling star radius (source 2024-2043)
const GALAXY_RADIAL_CDF = (function () {
  const N = 2e3;
  const rs = new Float64Array(N + 1),
    cdf = new Float64Array(N + 1);
  const step = (GALAXY_MAX_SAMPLE_R - GALAXY_CORE_RADIUS) / N;
  let acc = 0;
  for (let i = 0; i <= N; i++) {
    const r = GALAXY_CORE_RADIUS + i * step;
    rs[i] = r;
    if (i > 0) acc += r * galaxyRadialBound(r) * step;
    cdf[i] = acc;
  }
  const total = cdf[N] || 1;
  for (let i = 0; i <= N; i++) cdf[i] /= total;
  return { rs, cdf, N };
})();

function galaxySampleRadius(u) {
  const { rs, cdf, N } = GALAXY_RADIAL_CDF;
  let lo = 0,
    hi = N;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (cdf[mid] < u) lo = mid + 1;
    else hi = mid;
  }
  if (lo <= 0) return rs[0];
  const i0 = lo - 1,
    i1 = lo,
    c0 = cdf[i0],
    c1 = cdf[i1];
  const t = c1 > c0 ? (u - c0) / (c1 - c0) : 0;
  return rs[i0] + (rs[i1] - rs[i0]) * t;
}

// ===========================================================================
// Seeded PRNG (source lines 2333-2349)
// ===========================================================================
function mulberry32(seed) {
  let t = seed >>> 0;
  return function () {
    t = (t + 1831565813) | 0;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r = (r + Math.imul(r ^ (r >>> 7), 61 | r)) ^ r;
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

function rngRange(rng, min, max) {
  return min + rng() * (max - min);
}

function rngInt(rng, min, max) {
  return Math.floor(rngRange(rng, min, max + 1));
}

// ===========================================================================
// Star position (source lines 2539-2567)
// ===========================================================================
const GALAXY_POS_MAX_ATTEMPTS = 60;

function galaxySeedPosition(seed) {
  const rng = mulberry32((seed * 2654435761) ^ 625341585);
  let bestPos = null,
    bestDensity = -1;
  for (let attempt = 0; attempt < GALAXY_POS_MAX_ATTEMPTS; attempt++) {
    const r = galaxySampleRadius(rng());
    const angle = rng() * Math.PI * 2;
    const x = r * Math.cos(angle),
      y = r * Math.sin(angle);
    const density = galaxyDensityAt(x, y);
    if (density > bestDensity) {
      bestDensity = density;
      bestPos = { x, y };
    }
    if (rng() < density / galaxyRadialBound(r)) {
      return { x: PROC_REGION_CENTER.x + x, y: PROC_REGION_CENTER.y + y };
    }
  }
  return { x: PROC_REGION_CENTER.x + bestPos.x, y: PROC_REGION_CENTER.y + bestPos.y };
}

// ===========================================================================
// Color generation (source lines 2351-2438, 2457-2494, 3108-3226)
// ===========================================================================
function hslToRgb(h, s, l) {
  s /= 100;
  l /= 100;
  const c = (1 - Math.abs(2 * l - 1)) * s;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = l - c / 2;
  let r = 0,
    g = 0,
    b = 0;
  if (h < 60) {
    r = c; g = x; b = 0;
  } else if (h < 120) {
    r = x; g = c; b = 0;
  } else if (h < 180) {
    r = 0; g = c; b = x;
  } else if (h < 240) {
    r = 0; g = x; b = c;
  } else if (h < 300) {
    r = x; g = 0; b = c;
  } else {
    r = c; g = 0; b = x;
  }
  return { R: (r + m) * 255, G: (g + m) * 255, B: (b + m) * 255 };
}

function enforceBrightnessFloor(R, G, B) {
  const MIN_SUM = 288;
  let sum = R + G + B;
  if (sum < MIN_SUM) {
    const add = (MIN_SUM - sum) / 3;
    R = Math.min(255, R + add);
    G = Math.min(255, G + add);
    B = Math.min(255, B + add);
    sum = R + G + B;
    if (sum < MIN_SUM) {
      const rest = (MIN_SUM - sum) / 3;
      R = Math.min(255, R + rest);
      G = Math.min(255, G + rest);
      B = Math.min(255, B + rest);
    }
  }
  return { R: Math.round(R), G: Math.round(G), B: Math.round(B) };
}

function toHexColor(R, G, B) {
  const h = (n) => Math.max(0, Math.min(255, n)).toString(16).padStart(2, "0");
  return "#" + h(R) + h(G) + h(B);
}

function proceduralColor(rng, forcePurple) {
  let h, s, l;
  if (forcePurple || rng() < 0.16) {
    h = rngRange(rng, 268, 300);
    s = rngRange(rng, 55, 90);
    l = rngRange(rng, 42, 66);
  } else {
    h = rng() * 360;
    s = rngRange(rng, 25, 75);
    l = rngRange(rng, 30, 68);
  }
  const { R, G, B } = hslToRgb(h, s, l);
  const c = enforceBrightnessFloor(R, G, B);
  return toHexColor(c.R, c.G, c.B);
}

// Name-prefix tables — needed only to consume the RNG in the same order
// the game does (see the module-level extraction note above); the
// resulting name itself isn't used by the galaxy renderer.
const PROC_STAR_PREFIXES = [
  ["Ae","Al","Ar","Ari","Ca","Ce","Cyr","Da","De","Dra","Eli","Ery","Ga","Ka","Ke","Kyr","La",
    "Ly","Ma","Me","Na","Ne","Nex","Oly","Or","Ra","Re","Ryn","Sa","Se","Sy","Ta","Te","Va","Ve",
    "Vey","Xa","Xe","Za","Zy"],
  ["ba","bel","ca","cel","da","del","dra","el","fel","ga","gel","ka","kel","kra","la","len","ma",
    "mel","na","nel","nex","ra","rel","ren","sa","sel","sha","ta","tel","tha","va","vel","ven",
    "xa","xel","ya","zel","zen","zha","zor"],
  ["a","an","ar","ca","cel","cy","da","dra","el","en","er","ia","il","ir","ka","kel","la","le",
    "li","ma","mel","na","ne","ni","or","ra","re","ri","sa","se","ta","te","tha","va","ve","xa",
    "xe","ya","ze","zy"],
];

function proceduralStarName(rng, seed) {
  const n = rng() < 0.2 ? 1 : rng() < 0.35 ? 2 : 3;
  let name = PROC_STAR_PREFIXES[0][Math.floor(rng() * 40)];
  if (n > 1) name += PROC_STAR_PREFIXES[1][Math.floor(rng() * 40)];
  if (n > 2) name += PROC_STAR_PREFIXES[2][Math.floor(rng() * 40)];
  return name.replace(/^./, (c) => c.toUpperCase()) + "-" + seed;
}

const PROC_MUSIC_THEMES = ["interplanetary", "nightVision", "tauCeti", "signal"];
const PROC_MUSIC_BASE_HZ = {
  interplanetary: 48e3,
  nightVision: 44100,
  tauCeti: 36e3,
  signal: 44100,
};

function pickProcMusicSemitone(rng, baseHz) {
  if (baseHz < 4e4) {
    const weighted = [-2, -1, 0, 0, 1, 1, 2, 2, 3, 3];
    return weighted[Math.floor(rng() * weighted.length)];
  }
  return rngInt(rng, -3, 3);
}

/**
 * proceduralStarColor(seed) -> { color, name }
 *
 * Reproduces buildProceduralStarStub(seed)'s RNG draw sequence up through
 * and including the star's own color roll (source lines 3108-3226), exactly
 * as the game does it, so the color for a given seed matches the game
 * pixel-for-pixel. See the extraction note at the top of this file for why
 * the full sequence (GM mult, radius mult, name, theme, semitone) has to be
 * replayed before the color draw, not skipped.
 */
function proceduralStarColor(seed) {
  const rng = mulberry32((seed * 2654435761) ^ 2654435769);
  rngRange(rng, 0.5, 5.2); // starGmMult (unused here, but consumes the stream)
  rngRange(rng, 0.55, 3.8); // starRadMult
  const name = proceduralStarName(rng, seed); // variable-length draw
  const theme = PROC_MUSIC_THEMES[Math.floor(rng() * PROC_MUSIC_THEMES.length)];
  pickProcMusicSemitone(rng, PROC_MUSIC_BASE_HZ[theme]); // musicSemitone (unused here)
  const color = proceduralColor(rng);
  return { color, name };
}

// ===========================================================================
// Galaxy-dot rendering constants (source lines 10998-10999, 11129-11137, 11157)
// ===========================================================================
const GALAXY_DOT_RADIUS_PX = 1;
const GALAXY_DOT_COLOR_BUCKET = 24;
const GALAXY_DOT_OVERLAP_RATIO = 0.808;

function quantizeColorBucket(hex) {
  const h = hex.replace("#", "");
  const n = parseInt(h, 16);
  const step = GALAXY_DOT_COLOR_BUCKET;
  const r = Math.min(255, Math.round(((n >> 16) & 255) / step) * step);
  const g = Math.min(255, Math.round(((n >> 8) & 255) / step) * step);
  const b = Math.min(255, Math.round((n & 255) / step) * step);
  return toHexColor(r, g, b);
}

// ===========================================================================
// The 7 hardcoded (non-procedural) stars (source lines 1571-1917)
// See the module-level note above re: the Alpha Centauri binary/Proxima
// simplification (barycenter position, sub-pixel at this render scale).
// ===========================================================================
function buildFixedStars() {
  return [
    { key: "sun", name: "Sun", pos: SUN_POS, color: "#ffb020" },
    { key: "alphaCenA", name: "Alpha Centauri A (Rigil Kentaurus)", pos: ALPHA_CEN_ANCHOR_POS, color: "#fff3d6" },
    { key: "alphaCenB", name: "Alpha Centauri B (Toliman)", pos: ALPHA_CEN_ANCHOR_POS, color: "#ffb347" },
    { key: "proxima", name: "Proxima Centauri (Alpha Centauri C)", pos: ALPHA_CEN_ANCHOR_POS, color: "#c0392b" },
    { key: "tauCeti", name: "Tau Ceti", pos: TAU_CETI_POS, color: "#ffd27f" },
    { key: "gliese876", name: "Gliese 876", pos: GLIESE876_POS, color: "#e8623f" },
    { key: "sagittariusA", name: "Sagittarius A*", pos: SGR_A_POS, color: "#0a0a0a" },
  ];
}

module.exports = {
  // constants generate.js needs directly
  SGR_A_POS,
  GALAXY_DOT_OVERLAP_RATIO,
  GALAXY_DOT_RADIUS_PX,
  // core generation functions
  galaxySeedPosition,
  proceduralStarColor,
  quantizeColorBucket,
  buildFixedStars,
  // exposed for the validation sweep / debugging
  galaxyDensityAt,
  galaxyRadialBound,
  galaxySampleRadius,
  mulberry32,
  PROC_REGION_CENTER,
  GALAXY_SCALE_R,
  GALAXY_CORE_RADIUS,
  GALAXY_ARM_PHASE0,
  GALAXY_PITCH,
  GALAXY_NUM_ARMS,
};
